﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.IO;
using Newtonsoft.Json;


namespace CallWebAPIandDeserializeJson
{
    class Program
    {
        static void Main(string[] args)
        {
            string url = string.Empty;
            string resContent = string.Empty;
            WebRequest webRequest;
            WebResponse webResponse;

            url = "https://jsonplaceholder.typicode.com/todos/1";

            webRequest = WebRequest.Create(url);
            webResponse = webRequest.GetResponse();
            resContent = new StreamReader(webResponse.GetResponseStream()).ReadToEnd();

            Jsonplaceholder jsonplaceholder  = JsonConvert.DeserializeObject<Jsonplaceholder>(resContent);

            Console.WriteLine("Result of deserialize json:");
            string display = "userId : {0}";
            Console.WriteLine(string.Format(display, jsonplaceholder.userId));

            display = "ID : {0}";
            Console.WriteLine(string.Format(display, jsonplaceholder.id));

            display = "title : {0}";
            Console.WriteLine(string.Format(display, jsonplaceholder.title));

            display = "completed : {0}";
            Console.WriteLine(string.Format(display, jsonplaceholder.completed));
            Console.ReadLine();
        }
    }
}
